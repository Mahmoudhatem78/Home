import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.165.0/build/three.module.js';
const scene=new THREE.Scene();
scene.background=new THREE.Color(0x202830);
const camera=new THREE.PerspectiveCamera(75,innerWidth/innerHeight,0.1,1000);
const renderer=new THREE.WebGLRenderer({antialias:true});
renderer.setSize(innerWidth,innerHeight);
document.body.appendChild(renderer.domElement);

scene.add(new THREE.AmbientLight(0xffffff,1));
const light=new THREE.PointLight(0xffffff,20);
light.position.set(0,8,0); scene.add(light);

const floor=new THREE.Mesh(new THREE.BoxGeometry(20,.2,20),new THREE.MeshStandardMaterial({color:0x777777}));
scene.add(floor);

function box(w,h,d,c,x,y,z){
 const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshStandardMaterial({color:c}));
 m.position.set(x,y,z); scene.add(m); return m;
}
box(20,4,.2,0xffffff,0,2,-10);
box(20,4,.2,0xffffff,0,2,10);
box(.2,4,20,0xffffff,-10,2,0);
box(.2,4,20,0xffffff,10,2,0);
box(20,.2,20,0xcccccc,0,4,0); // ceiling

box(3,.8,2,0x2244ff,0,.4,-6); // bed
box(2,1,1,0x8b5a2b,6,.5,-5); // desk
box(1.5,2.5,1,0x553311,-7,1.25,-5); // wardrobe
box(3,.1,3,0x0099aa,6,.05,6); // pool

camera.position.set(0,1.7,5);

let F=false,B=false,L=false,R=false;
const bind=(id,set)=>{
 let e=document.getElementById(id);
 e.ontouchstart=()=>window[set]=true;
 e.ontouchend=()=>window[set]=false;
};
window.F=window.B=window.L=window.R=false;
bind('f','F'); bind('b','B'); bind('l','L'); bind('r','R');

let lastX=0,drag=false;
document.addEventListener('touchstart',e=>{drag=true;lastX=e.touches[0].clientX;});
document.addEventListener('touchmove',e=>{if(!drag)return;let dx=e.touches[0].clientX-lastX;camera.rotation.y-=dx*0.005;lastX=e.touches[0].clientX;});
document.addEventListener('touchend',()=>drag=false);

function animate(){
 requestAnimationFrame(animate);
 if(window.F) camera.position.z-=0.08;
 if(window.B) camera.position.z+=0.08;
 if(window.L) camera.position.x-=0.08;
 if(window.R) camera.position.x+=0.08;
 renderer.render(scene,camera);
}
animate();